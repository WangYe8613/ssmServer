create view UserVO as
select `ssmServer`.`UserEO`.`uuid`        AS `uuid`,
       `ssmServer`.`UserEO`.`name`        AS `name`,
       `ssmServer`.`UserEO`.`password`    AS `password`,
       `ssmServer`.`UserEO`.`token`       AS `token`,
       `ssmServer`.`UserEO`.`lastOpDate`  AS `lastOpDate`,
       `ssmServer`.`UserEO`.`createDate`  AS `createDate`,
       `ssmServer`.`UserEO`.`deleted`     AS `deleted`,
       `ssmServer`.`UserEO`.`description` AS `description`
from `ssmServer`.`UserEO`
where isnull(`ssmServer`.`UserEO`.`deleted`);

-- comment on column UserVO.lastOpDate not supported: last operation date

